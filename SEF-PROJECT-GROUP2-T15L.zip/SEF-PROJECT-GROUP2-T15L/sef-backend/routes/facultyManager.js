const express = require("express");
const router = express.Router();
const pool = require("../db");


router.get("/venues", async (req, res) => {
  try {
    const result = await pool.query("SELECT * FROM venues");
    res.json(result.rows);
  } catch (err) {
    res.status(500).json(err.message);
  }
});


router.post("/venues/block", async (req, res) => {
  const { venue_id, start_date, end_date, reason } = req.body;

  try {
    await pool.query(
      `INSERT INTO venue_blocks (venue_id, start_date, end_date, reason)
       VALUES ($1, $2, $3, $4)`,
      [venue_id, start_date, end_date, reason]
    );

    res.json({ message: "Venue blocked successfully" });
  } catch (err) {
    res.status(500).json(err.message);
  }
});


router.get("/venues/:id/blocks", async (req, res) => {
  const venueId = req.params.id;

  try {
    const result = await pool.query(
      `SELECT * FROM venue_blocks
       WHERE venue_id = $1
       ORDER BY start_date`,
      [venueId]
    );

    res.json(result.rows);
  } catch (err) {
    res.status(500).json(err.message);
  }
});


router.get("/events", async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        e.id,
        e.title AS event_name,
        e.description,
        e.event_date,
        u.name AS organiser_name
      FROM events e
      JOIN users u ON e.organiser_id = u.id
      ORDER BY e.event_date ASC
    `);

    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to fetch events" });
  }
});


module.exports = router;
