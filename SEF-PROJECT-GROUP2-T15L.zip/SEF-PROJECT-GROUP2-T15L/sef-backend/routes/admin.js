const express = require("express");
const router = express.Router();
const pool = require("../db");


/* GET ALL USERS */
router.get("/users", async (req, res) => {
  try {
    const result = await pool.query(`SELECT id, name, role, username FROM users ORDER BY id ASC`);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch users" });
  }
});

/* ADD NEW USER */
router.post("/users", async (req, res) => {
  const { name, role, username, password } = req.body;
  try {
    await pool.query(
      `INSERT INTO users (name, role, username, password) VALUES ($1, $2, $3, $4)`,
      [name, role, username, password]
    );
    res.json({ message: "User added successfully" });
  } catch (err) {
    res.status(500).json({ message: "Failed to add user" });
  }
});

/* DELETE USER */
router.delete("/users/:id", async (req, res) => {
  const userId = req.params.id;
  try {
    await pool.query(`DELETE FROM users WHERE id = $1`, [userId]);
    res.json({ message: "User removed successfully" });
  } catch (err) {
    res.status(500).json({ message: "Failed to remove user" });
  }
});



/* GET ALL BOOKINGS */
router.get("/bookings/all", async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        b.id, 
        u.name AS student_name, 
        v.venue_name, 
        b.booking_date, 
        b.start_time, 
        b.end_time, 
        b.status,
        b.purpose
      FROM bookings b
      JOIN users u ON b.user_id = u.id
      JOIN venues v ON b.venue_id = v.id
      ORDER BY b.created_at DESC
    `);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch bookings" });
  }
});

/* MODIFY A BOOKING (Admin) */
router.put("/bookings/:id", async (req, res) => {
  const bookingId = req.params.id;
  const { booking_date, start_time, end_time, status } = req.body;

  try {
    await pool.query(
      `UPDATE bookings SET booking_date = $1, start_time = $2, end_time = $3, status = $4 WHERE id = $5`,
      [booking_date, start_time, end_time, status, bookingId]
    );
    res.json({ message: "Booking updated successfully" });
  } catch (err) {
    res.status(500).json({ message: "Failed to update booking" });
  }
});


router.get("/bookings/pending", async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        b.id,
        u.name AS student_name,
        v.venue_name,
        b.booking_date,
        b.start_time,
        b.end_time,
        b.status,
        b.purpose
      FROM bookings b
      JOIN users u ON b.user_id = u.id
      JOIN venues v ON b.venue_id = v.id
      WHERE b.status = 'PENDING'
      ORDER BY b.created_at ASC
    `);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch pending bookings" });
  }
});

router.put("/bookings/:id/approve", async (req, res) => {
  const bookingId = req.params.id;
  try {
    await pool.query(`UPDATE bookings SET status = 'APPROVED' WHERE id = $1`, [bookingId]);
    res.json({ message: "Booking approved" });
  } catch (err) {
    res.status(500).json({ message: "Failed to approve booking" });
  }
});

router.put("/bookings/:id/reject", async (req, res) => {
  const bookingId = req.params.id;
  try {
    await pool.query(`UPDATE bookings SET status = 'REJECTED' WHERE id = $1`, [bookingId]);
    res.json({ message: "Booking rejected" });
  } catch (err) {
    res.status(500).json({ message: "Failed to reject booking" });
  }
});


router.get("/venues", async (req, res) => {
  try {
    const result = await pool.query(`SELECT * FROM venues ORDER BY id ASC`);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch venues" });
  }
});

/* ADD NEW VENUE */
router.post("/venues", async (req, res) => {
  const { venue_name, capacity, location } = req.body;

  if (!venue_name || !capacity || !location) {
    return res.status(400).json({ message: "All fields are required" });
  }

  try {
    await pool.query(
      `INSERT INTO venues (venue_name, capacity, location)
       VALUES ($1, $2, $3)`,
      [venue_name, capacity, location]
    );

    res.json({ message: "Venue added successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to add venue" });
  }
});

// GET ADMIN STATISTICS
router.get("/stats", async (req, res) => {
  try {
    // Total bookings
    const totalBookingsRes = await pool.query("SELECT COUNT(*) FROM bookings");
    const totalBookings = totalBookingsRes.rows[0].count;

    // Approved bookings
    const approvedBookingsRes = await pool.query(
      "SELECT COUNT(*) FROM bookings WHERE status='APPROVED'"
    );
    const approvedBookings = approvedBookingsRes.rows[0].count;

    // Rejected bookings
    const rejectedBookingsRes = await pool.query(
      "SELECT COUNT(*) FROM bookings WHERE status='REJECTED'"
    );
    const rejectedBookings = rejectedBookingsRes.rows[0].count;

    // Pending bookings
    const pendingBookingsRes = await pool.query(
      "SELECT COUNT(*) FROM bookings WHERE status='PENDING'"
    );
    const pendingBookings = pendingBookingsRes.rows[0].count;

    // Total events
    const totalEventsRes = await pool.query("SELECT COUNT(*) FROM events");
    const totalEvents = totalEventsRes.rows[0].count;

    // Total users
    const totalUsersRes = await pool.query("SELECT COUNT(*) FROM users");
    const totalUsers = totalUsersRes.rows[0].count;

    res.json({
      totalBookings,
      approvedBookings,
      rejectedBookings,
      pendingBookings,
      totalEvents,
      totalUsers,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to load statistics" });
  }
});


module.exports = router;
