const express = require("express");
const router = express.Router();
const pool = require("../db");


router.get("/venues/search", async (req, res) => {
  const { date, startTime, endTime } = req.query;

  try {
    const result = await pool.query(
      `
      SELECT * FROM venues
      WHERE id NOT IN (
        SELECT venue_id FROM bookings
        WHERE booking_date = $1
          AND status IN ('PENDING', 'APPROVED')
          AND NOT (
            end_time <= $2 OR start_time >= $3
          )
      )
      AND id NOT IN (
        SELECT venue_id FROM venue_blocks
        WHERE $1 BETWEEN start_date AND end_date
      )
      `,
      [date, startTime, endTime]
    );

    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to search venues" });
  }
});


router.post("/bookings", async (req, res) => {
  const { venueId, bookingDate, startTime, endTime, userId, purpose } = req.body;

  if (!userId) return res.status(400).json({ message: "User not authenticated" });
  if (!purpose || !purpose.trim()) return res.status(400).json({ message: "Purpose is required" });

  try {
    // Check blocked venue
    const blockCheck = await pool.query(
      `
      SELECT * FROM venue_blocks
      WHERE venue_id = $1
      AND $2 BETWEEN start_date AND end_date
      `,
      [venueId, bookingDate]
    );

    if (blockCheck.rows.length > 0) {
      return res.status(400).json({ message: "Venue is blocked for the selected date" });
    }

    // Create booking
    await pool.query(
      `
      INSERT INTO bookings
      (user_id, venue_id, booking_date, start_time, end_time, status, purpose)
      VALUES ($1, $2, $3, $4, $5, 'PENDING', $6)
      `,
      [userId, venueId, bookingDate, startTime, endTime, purpose]
    );

    res.json({ message: "Booking submitted for approval" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to create booking" });
  }
});


router.get("/bookings/:userId", async (req, res) => {
  const { userId } = req.params;

  try {
    const result = await pool.query(
      `
      SELECT 
        b.id,
        v.venue_name,
        b.booking_date,
        b.start_time,
        b.end_time,
        b.status,
        b.purpose
      FROM bookings b
      JOIN venues v ON b.venue_id = v.id
      WHERE b.user_id = $1
      ORDER BY b.created_at DESC
      `,
      [userId]
    );

    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to fetch bookings" });
  }
});


router.put("/bookings/:bookingId", async (req, res) => {
  const { bookingId } = req.params;
  const { bookingDate, startTime, endTime, userId, purpose } = req.body;

  if (!userId) return res.status(400).json({ message: "User not authenticated" });
  if (!purpose || !purpose.trim()) return res.status(400).json({ message: "Purpose is required" });

  try {
    const bookingCheck = await pool.query(
      `SELECT * FROM bookings WHERE id = $1 AND user_id = $2`,
      [bookingId, userId]
    );
    if (bookingCheck.rows.length === 0) return res.status(404).json({ message: "Booking not found" });

    const blockCheck = await pool.query(
      `SELECT * FROM venue_blocks WHERE venue_id = $1 AND $2 BETWEEN start_date AND end_date`,
      [bookingCheck.rows[0].venue_id, bookingDate]
    );
    if (blockCheck.rows.length > 0) return res.status(400).json({ message: "Venue is blocked for the selected date" });

    const conflictCheck = await pool.query(
      `
      SELECT * FROM bookings
      WHERE venue_id = $1
        AND id != $2
        AND booking_date = $3
        AND status IN ('PENDING','APPROVED')
        AND NOT (end_time <= $4 OR start_time >= $5)
      `,
      [bookingCheck.rows[0].venue_id, bookingId, bookingDate, startTime, endTime]
    );
    if (conflictCheck.rows.length > 0) return res.status(400).json({ message: "Venue already booked for the selected time" });

    await pool.query(
      `
      UPDATE bookings
      SET booking_date = $1, start_time = $2, end_time = $3, status = 'PENDING', purpose = $4
      WHERE id = $5
      `,
      [bookingDate, startTime, endTime, purpose, bookingId]
    );

    res.json({ message: "Booking updated successfully (Pending Approval)" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to update booking" });
  }
});


router.delete("/bookings/:bookingId", async (req, res) => {
  const { bookingId } = req.params;
  const { userId } = req.body;

  if (!userId) return res.status(400).json({ message: "User not authenticated" });

  try {
    const bookingCheck = await pool.query(
      `SELECT * FROM bookings WHERE id = $1 AND user_id = $2`,
      [bookingId, userId]
    );
    if (bookingCheck.rows.length === 0) return res.status(404).json({ message: "Booking not found" });

    await pool.query(`DELETE FROM bookings WHERE id = $1`, [bookingId]);
    res.json({ message: "Booking cancelled successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to cancel booking" });
  }
});

module.exports = router;
