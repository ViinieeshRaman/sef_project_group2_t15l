const express = require("express");
const router = express.Router();
const pool = require("../db");


router.post("/login", async (req, res) => {
  const { username, password } = req.body;

  try {
    const result = await pool.query(
      `
      SELECT id, name, role
      FROM users
      WHERE username = $1 AND password = $2
      `,
      [username, password]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ message: "Invalid username or password" });
    }

    res.json(result.rows[0]); 
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Login failed" });
  }
});


router.post("/signup", async (req, res) => {
  const { name, username, password, role } = req.body;

 
  const validRoles = ["STUDENT", "EVENT_ORGANISER", "GUEST"];
  if (!validRoles.includes(role)) {
    return res.status(400).json({ message: "Invalid role" });
  }

  try {
    
    const check = await pool.query(
      `SELECT id FROM users WHERE username = $1`,
      [username]
    );

    if (check.rows.length > 0) {
      return res.status(400).json({ message: "Username already taken" });
    }

    await pool.query(
      `
      INSERT INTO users (name, username, password, role)
      VALUES ($1, $2, $3, $4)
      `,
      [name, username, password, role]
    );

    res.json({ message: "Account created successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Signup failed" });
  }
});

module.exports = router;
