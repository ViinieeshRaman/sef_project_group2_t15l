const express = require("express");
const router = express.Router();
const pool = require("../db"); 



router.get("/my-events", async (req, res) => {
  const organiserId = req.query.user_id; 

  if (!organiserId) {
    return res.status(400).json({ message: "Missing organiser ID" });
  }

  try {
    const result = await pool.query(
      `
      SELECT e.*, 
             COALESCE(b.status, 'Not Booked') AS booking_status
      FROM events e
      LEFT JOIN bookings b
        ON e.id = b.event_id
      WHERE e.organiser_id = $1
      ORDER BY e.event_date ASC
      `,
      [organiserId]
    );

    res.json(result.rows);
  } catch (err) {
    console.error("Error fetching organiser events:", err);
    res.status(500).json({ message: "Failed to load events" });
  }
});



router.get("/events", async (req, res) => {
  const organiserId = req.query.user_id;

  if (!organiserId) {
    return res.status(400).json({ message: "Missing organiser ID" });
  }

  try {
    const result = await pool.query(
      `
      SELECT *
      FROM events
      WHERE organiser_id = $1
      ORDER BY event_date ASC
      `,
      [organiserId]
    );

    res.json(result.rows);
  } catch (err) {
    console.error("Error fetching events:", err);
    res.status(500).json({ message: "Failed to load events" });
  }
});



router.post("/bookings", async (req, res) => {
  const {
    event_id,
    venue_id,
    booking_date,
    start_time,
    end_time,
    resources,
    user_id 
  } = req.body;

  if (!event_id || !venue_id || !booking_date || !start_time || !end_time || !user_id) {
    return res.status(400).json({ message: "Missing required fields" });
  }

  try {
    
    const bookingResult = await pool.query(
      `
      INSERT INTO bookings
      (user_id, venue_id, booking_date, start_time, end_time, status, event_id)
      VALUES ($1,$2,$3,$4,$5,'PENDING',$6)
      RETURNING id
      `,
      [
        user_id,
        venue_id,
        booking_date,
        start_time,
        end_time,
        event_id
      ]
    );

    const bookingId = bookingResult.rows[0].id;

    
    if (Array.isArray(resources) && resources.length > 0) {
      for (const resource of resources) {
        await pool.query(
          `
          INSERT INTO booking_resources (booking_id, resource_name)
          VALUES ($1,$2)
          `,
          [bookingId, resource]
        );
      }
    }

    res.json({
      message: "Venue booking & resource request submitted successfully"
    });

  } catch (err) {
    console.error("Booking error:", err);
    res.status(500).json({ message: "Booking failed" });
  }
});



router.get("/bookings", async (req, res) => {
  const userId = req.query.user_id; 

  if (!userId) {
    return res.status(400).json({ message: "Missing user ID" });
  }

  try {
    const result = await pool.query(
      `
      SELECT 
        b.*,
        v.venue_name,
        e.title AS event_title
      FROM bookings b
      JOIN venues v ON b.venue_id = v.id
      JOIN events e ON b.event_id = e.id
      WHERE b.user_id = $1
      ORDER BY b.booking_date DESC
      `,
      [userId]
    );

    res.json(result.rows);
  } catch (err) {
    console.error("Error loading bookings:", err);
    res.status(500).json({ message: "Failed to load bookings" });
  }
});



router.post("/events", async (req, res) => {
  const { title, description, event_date, organiser_id } = req.body; 

  if (!title || !event_date || !organiser_id) {
    return res.status(400).json({ message: "Missing required fields" });
  }

  try {
    const result = await pool.query(
      `
      INSERT INTO events (title, description, event_date, organiser_id)
      VALUES ($1,$2,$3,$4)
      RETURNING id
      `,
      [title, description, event_date, organiser_id]
    );

    res.json({ message: "Event created successfully", eventId: result.rows[0].id });
  } catch (err) {
    console.error("Error creating event:", err);
    res.status(500).json({ message: "Failed to create event" });
  }
});



router.get("/feedbacks", async (req, res) => {
  const organiserId = req.query.user_id;

  if (!organiserId) {
    return res.status(400).json({ message: "Missing organiser ID" });
  }

  try {
    const result = await pool.query(
      `
      SELECT 
        f.id,
        f.rating,
        f.comment,
        f.created_at,
        e.title AS event_title
      FROM event_feedback f
      JOIN events e ON f.event_id = e.id
      WHERE e.organiser_id = $1
      ORDER BY f.created_at DESC
      `,
      [organiserId]
    );

    res.json(result.rows);
  } catch (err) {
    console.error("Error fetching feedbacks:", err);
    res.status(500).json({ message: "Failed to load feedbacks" });
  }
});

module.exports = router;
