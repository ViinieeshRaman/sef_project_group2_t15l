const express = require("express");
const router = express.Router();
const pool = require("../db");


router.get("/events", async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT e.id, e.title AS event_name, e.description, e.event_date, u.name AS organiser_name
      FROM events e
      JOIN users u ON e.organiser_id = u.id
      ORDER BY e.event_date ASC
    `);
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to fetch events" });
  }
});


router.post("/rsvp", async (req, res) => {
  const { userId, eventId } = req.body;

  if (!userId) return res.status(400).json({ message: "User not authenticated" });

  try {
    const check = await pool.query(
      `SELECT * FROM guest_rsvps WHERE user_id = $1 AND event_id = $2`,
      [userId, eventId]
    );

    if (check.rows.length > 0) {
      return res.status(400).json({ message: "Already RSVPed for this event" });
    }

    await pool.query(
      `INSERT INTO guest_rsvps (user_id, event_id) VALUES ($1, $2)`,
      [userId, eventId]
    );

    res.json({ message: "RSVP successful" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "RSVP failed" });
  }
});


router.get("/rsvps/:userId", async (req, res) => {
  const { userId } = req.params;

  try {
    const result = await pool.query(`
      SELECT e.id, e.title AS event_name, e.description, e.event_date, u.name AS organiser_name
      FROM guest_rsvps r
      JOIN events e ON r.event_id = e.id
      JOIN users u ON e.organiser_id = u.id
      WHERE r.user_id = $1
      ORDER BY e.event_date ASC
    `, [userId]);

    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to fetch RSVPs" });
  }
});


router.post("/feedback", async (req, res) => {
  const { userId, eventId, rating, comment } = req.body;

  if (!userId || !eventId || !rating) {
    return res.status(400).json({ message: "Missing required fields" });
  }

  try {
    
    const check = await pool.query(
      `SELECT * FROM event_feedback WHERE user_id=$1 AND event_id=$2`,
      [userId, eventId]
    );

    if (check.rows.length > 0) {
      return res.status(400).json({ message: "Feedback already submitted" });
    }

    await pool.query(
      `INSERT INTO event_feedback (user_id, event_id, rating, comment)
       VALUES ($1, $2, $3, $4)`,
      [userId, eventId, rating, comment]
    );

    res.json({ message: "Feedback submitted successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to submit feedback" });
  }
});


module.exports = router;
