import { useEffect, useState } from "react";
import axios from "axios";

export default function MyEvents({ user }) {
  const [events, setEvents] = useState([]);
  const [feedback, setFeedback] = useState({});

  useEffect(() => {
    axios
      .get(`http://localhost:5000/api/guest/rsvps/${user.id}`)
      .then((res) => setEvents(res.data))
      .catch((err) => console.error(err));
  }, [user.id]);

  const handleChange = (eventId, field, value) => {
    setFeedback({
      ...feedback,
      [eventId]: {
        ...feedback[eventId],
        [field]: value,
      },
    });
  };

  const submitFeedback = async (eventId) => {
    const data = feedback[eventId];

    if (!data?.rating) {
      alert("Please provide rating");
      return;
    }

    try {
      await axios.post("http://localhost:5000/api/guest/feedback", {
        userId: user.id,
        eventId,
        rating: data.rating,
        comment: data.comment || "",
      });

      alert("Feedback submitted!");
    } catch (err) {
      alert(err.response?.data?.message || "Failed to submit feedback");
    }
  };

  return (
    <div>
      <h2>My RSVPed Events</h2>

      {events.length === 0 ? (
        <p>No events RSVPed yet</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Event</th>
              <th>Description</th>
              <th>Organiser</th>
              <th>Date</th>
              <th>Rating</th>
              <th>Comment</th>
              <th>Action</th>
            </tr>
          </thead>

          <tbody>
            {events.map((e) => (
              <tr key={e.id}>
                <td>{e.event_name}</td>
                <td>{e.description}</td>
                <td>{e.organiser_name}</td>
                <td>{e.event_date}</td>

                <td>
                  <select
                    onChange={(ev) =>
                      handleChange(e.id, "rating", ev.target.value)
                    }
                  >
                    <option value="">Rate</option>
                    <option value="1">1 ⭐</option>
                    <option value="2">2 ⭐</option>
                    <option value="3">3 ⭐</option>
                    <option value="4">4 ⭐</option>
                    <option value="5">5 ⭐</option>
                  </select>
                </td>

                <td>
                  <input
                    type="text"
                    placeholder="Write feedback"
                    onChange={(ev) =>
                      handleChange(e.id, "comment", ev.target.value)
                    }
                  />
                </td>

                <td>
                  <button onClick={() => submitFeedback(e.id)}>
                    Submit
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
