import axios from "axios";

export default function AvailableVenues({ venues, searchData }) {
  const book = async (venueId) => {
    await axios.post("http://localhost:5000/api/student/bookings", {
      venueId,
      bookingDate: searchData.date,
      startTime: searchData.startTime,
      endTime: searchData.endTime,
    });
    alert("Booking submitted (Pending Approval)");
  };

  return (
    <table>
      <tbody>
        {venues.map((v) => (
          <tr key={v.id}>
            <td>{v.venue_name}</td>
            <td>{v.capacity}</td>
            <td>
              <button onClick={() => book(v.id)}>Book</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
