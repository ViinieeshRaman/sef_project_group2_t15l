import axios from "axios";
import { useEffect, useState } from "react";
import "../styles/faculty.css";

export default function VenueBlocker() {
  const [venues, setVenues] = useState([]);
  const [form, setForm] = useState({
    venue_id: "",
    start_date: "",
    end_date: "",
    reason: ""
  });

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/faculty/venues")
      .then(res => setVenues(res.data));
  }, []);

  function handleChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  function blockVenue(e) {
    e.preventDefault();

    axios
      .post("http://localhost:5000/api/faculty/venues/block", form)
      .then(() => {
        alert("Venue blocked successfully");
        setForm({
          venue_id: "",
          start_date: "",
          end_date: "",
          reason: ""
        });
      })
      .catch(() => alert("Failed to block venue"));
  }

  return (
    <div className="faculty-page">
      <form className="block-card" onSubmit={blockVenue}>
        <h2>Block Venue</h2>

        <select
          name="venue_id"
          value={form.venue_id}
          onChange={handleChange}
          required
        >
          <option value="">Select Venue</option>
          {venues.map(v => (
            <option key={v.id} value={v.id}>
              {v.venue_name}
            </option>
          ))}
        </select>

        <input
          type="date"
          name="start_date"
          value={form.start_date}
          onChange={handleChange}
          required
        />

        <input
          type="date"
          name="end_date"
          value={form.end_date}
          onChange={handleChange}
          required
        />

        <input
          type="text"
          name="reason"
          placeholder="Reason (e.g. Maintenance, Exam Setup)"
          value={form.reason}
          onChange={handleChange}
        />

        <button type="submit">Block Venue</button>
      </form>
    </div>
  );
}
