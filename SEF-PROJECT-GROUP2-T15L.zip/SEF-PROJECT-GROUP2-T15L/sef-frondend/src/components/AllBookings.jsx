import axios from "axios";
import { useEffect, useState } from "react";

export default function AllBookings() {
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    fetchAllBookings();
  }, []);

  function fetchAllBookings() {
    axios
      .get("http://localhost:5000/api/admin/bookings/all")
      .then((res) => setBookings(res.data));
  }

  function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-CA");
  }

  return (
    <div>
      <h2>All Bookings</h2>

      <table>
        <thead>
          <tr>
            <th>Student</th>
            <th>Venue</th>
            <th>Date</th>
            <th>Time</th>
            <th>Status</th>
            <th>Purpose</th>
          </tr>
        </thead>

        <tbody>
          {bookings.length === 0 ? (
            <tr>
              <td colSpan="6" align="center">
                No bookings found
              </td>
            </tr>
          ) : (
            bookings.map((b) => (
              <tr key={b.id}>
                <td>{b.student_name}</td>
                <td>{b.venue_name}</td>
                <td>{formatDate(b.booking_date)}</td>
                <td>
                  {b.start_time} – {b.end_time}
                </td>
                <td>{b.status}</td>
                <td>{b.purpose}</td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}
