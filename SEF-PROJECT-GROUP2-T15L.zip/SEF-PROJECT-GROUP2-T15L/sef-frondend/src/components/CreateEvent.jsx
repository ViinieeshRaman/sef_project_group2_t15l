import { useState } from "react";

export default function CreateEvent() {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [date, setDate] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();

    const user = JSON.parse(localStorage.getItem("user"));
    if (!user) return alert("You must be logged in as an organiser to create events");

    if (!title || !date) return alert("Please fill in all required fields");

    try {
      const response = await fetch("http://localhost:5000/api/event-organiser/events", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          description,
          event_date: date,
          organiser_id: user.id 
        })
      });

      const data = await response.json();

      if (response.ok) {
        alert("Event created successfully. Event ID: " + data.eventId);
        setTitle("");
        setDescription("");
        setDate("");
      } else {
        alert("Failed to create event: " + data.message);
      }
    } catch (err) {
      console.error(err);
      alert("Failed to create event: " + err.message);
    }
  };

  return (
    <div className="card">
      <h2>Create Event</h2>

      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Event Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />

        <textarea
          placeholder="Event Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />

        <input
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          required
        />

        <button type="submit">Create Event</button>
      </form>
    </div>
  );
}
