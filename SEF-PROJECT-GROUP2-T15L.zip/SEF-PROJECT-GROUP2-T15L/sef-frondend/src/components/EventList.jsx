import { useEffect, useState } from "react";
import axios from "axios";

export default function EventList() {
  const [events, setEvents] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/faculty/events")
      .then((res) => setEvents(res.data))
      .catch((err) => console.error(err));
  }, []);

  const formatDate = (dateString) => new Date(dateString).toLocaleDateString("en-CA");

  return (
    <div>
      <h2>All Events (List View)</h2>
      {events.length === 0 ? (
        <p>No events found</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Event</th>
              <th>Organiser</th>
              <th>Description</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            {events.map((e) => (
              <tr key={e.id}>
                <td>{e.event_name}</td>
                <td>{e.organiser_name}</td>
                <td>{e.description}</td>
                <td>{formatDate(e.event_date)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
