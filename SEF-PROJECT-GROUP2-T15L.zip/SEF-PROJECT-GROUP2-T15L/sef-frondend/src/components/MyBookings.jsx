import { useEffect, useState } from "react";
import axios from "axios";

export default function MyBookings() {
  const [bookings, setBookings] = useState([]);
  const user = JSON.parse(localStorage.getItem("user"));

  const fetchBookings = () => {
    axios
      .get(`http://localhost:5000/api/student/bookings/${user.id}`)
      .then((res) => setBookings(res.data))
      .catch((err) => console.error(err));
  };

  useEffect(() => {
    fetchBookings();
  }, []);

  const cancelBooking = (bookingId) => {
    if (!window.confirm("Are you sure you want to cancel this booking?")) return;

    axios
      .delete(`http://localhost:5000/api/student/bookings/${bookingId}`, { data: { userId: user.id } })
      .then(() => {
        alert("Booking cancelled");
        fetchBookings();
      })
      .catch((err) => alert(err.response?.data?.message || "Cancel failed"));
  };

  const modifyBooking = (booking) => {
    const newDate = prompt("Enter new date (YYYY-MM-DD):", booking.booking_date);
    const newStart = prompt("Enter new start time (HH:MM:SS):", booking.start_time);
    const newEnd = prompt("Enter new end time (HH:MM:SS):", booking.end_time);
    const newPurpose = prompt("Enter new purpose:", booking.purpose || "");

    if (!newDate || !newStart || !newEnd || !newPurpose) return;

    axios
      .put(`http://localhost:5000/api/student/bookings/${booking.id}`, {
        userId: user.id,
        bookingDate: newDate,
        startTime: newStart,
        endTime: newEnd,
        purpose: newPurpose,
      })
      .then(() => {
        alert("Booking updated (Pending Approval)");
        fetchBookings();
      })
      .catch((err) => alert(err.response?.data?.message || "Update failed"));
  };

  if (bookings.length === 0) return <p>No bookings found</p>;

  return (
    <table>
      <thead>
        <tr>
          <th>Venue</th>
          <th>Date</th>
          <th>Start</th>
          <th>End</th>
          <th>Purpose</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        {bookings.map((b) => (
          <tr key={b.id}>
            <td>{b.venue_name}</td>
            <td>{b.booking_date}</td>
            <td>{b.start_time}</td>
            <td>{b.end_time}</td>
            <td>{b.purpose}</td> {/* new */}
            <td>{b.status}</td>
            <td>
              <button onClick={() => modifyBooking(b)}>Modify</button>
              <button onClick={() => cancelBooking(b.id)}>Cancel</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
