import { useEffect, useState } from "react";
import axios from "axios";

export default function ViewEvents({ user }) {
  const [events, setEvents] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/guest/events")
      .then((res) => setEvents(res.data))
      .catch((err) => {
        console.error(err);
        alert("Failed to load events");
      });
  }, []);

  const rsvp = async (eventId) => {
    try {
      await axios.post("http://localhost:5000/api/guest/rsvp", {
        userId: user.id,
        eventId,
      });
      alert("RSVP successful");
      setEvents(events.filter((e) => e.id !== eventId));
    } catch (err) {
      alert(err.response?.data?.message || "RSVP failed");
    }
  };

  return (
    <div>
      <h2>Available Events</h2>
      {events.length === 0 ? (
        <p>No events available</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Event</th>
              <th>Description</th>
              <th>Organiser</th>
              <th>Date</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {events.map((e) => (
              <tr key={e.id}>
                <td>{e.event_name}</td>
                <td>{e.description}</td>
                <td>{e.organiser_name}</td>
                <td>{e.event_date}</td>
                <td>
                  <button onClick={() => rsvp(e.id)}>RSVP</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
