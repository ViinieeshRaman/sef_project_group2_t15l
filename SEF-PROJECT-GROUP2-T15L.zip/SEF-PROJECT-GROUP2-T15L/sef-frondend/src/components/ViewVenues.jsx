import { useEffect, useState } from "react";
import axios from "axios";

export default function ViewVenues() {
  const [venues, setVenues] = useState([]);

  const [venueName, setVenueName] = useState("");
  const [capacity, setCapacity] = useState("");
  const [location, setLocation] = useState("");

  useEffect(() => {
    fetchVenues();
  }, []);

  function fetchVenues() {
    axios
      .get("http://localhost:5000/api/admin/venues")
      .then((res) => setVenues(res.data))
      .catch((err) => console.error(err));
  }

  function addVenue() {
    if (!venueName || !capacity || !location) {
      alert("Please fill all fields");
      return;
    }

    axios
      .post("http://localhost:5000/api/admin/venues", {
        venue_name: venueName,
        capacity,
        location,
      })
      .then(() => {
        alert("Venue added successfully");
        setVenueName("");
        setCapacity("");
        setLocation("");
        fetchVenues(); // refresh list
      })
      .catch((err) => {
        console.error(err);
        alert(err.response?.data?.message || "Failed to add venue");
      });
  }

  return (
    <div>
      <h2>Manage Venues</h2>

      {/* ADD VENUE FORM */}
      <div style={{ marginBottom: "20px" }}>
        <h3>Add New Venue</h3>

        <input
          type="text"
          placeholder="Venue Name"
          value={venueName}
          onChange={(e) => setVenueName(e.target.value)}
        />

        <input
          type="number"
          placeholder="Capacity"
          value={capacity}
          onChange={(e) => setCapacity(e.target.value)}
        />

        <input
          type="text"
          placeholder="Location"
          value={location}
          onChange={(e) => setLocation(e.target.value)}
        />

        <button onClick={addVenue}>Add Venue</button>
      </div>

      {/* VENUE LIST */}
      {venues.length === 0 ? (
        <p>No venues found</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Venue Name</th>
              <th>Capacity</th>
              <th>Location</th>
            </tr>
          </thead>
          <tbody>
            {venues.map((v) => (
              <tr key={v.id}>
                <td>{v.venue_name}</td>
                <td>{v.capacity}</td>
                <td>{v.location}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
