import { useEffect, useState } from "react";
import axios from "axios";

export default function ManageUsers() {
  const [users, setUsers] = useState([]);
  const [name, setName] = useState("");
  const [role, setRole] = useState("STUDENT");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const fetchUsers = () => {
    axios.get("http://localhost:5000/api/admin/users")
      .then(res => setUsers(res.data))
      .catch(err => console.error(err));
  };

  useEffect(() => fetchUsers(), []);

  const addUser = () => {
    if (!name || !username || !password) return alert("Fill all fields");

    axios.post("http://localhost:5000/api/admin/users", { name, role, username, password })
      .then(() => {
        alert("User added");
        setName(""); setUsername(""); setPassword("");
        fetchUsers();
      })
      .catch(err => alert(err.response?.data?.message || "Failed to add user"));
  };

  const removeUser = (id) => {
    if (!window.confirm("Are you sure?")) return;
    axios.delete(`http://localhost:5000/api/admin/users/${id}`)
      .then(() => fetchUsers())
      .catch(err => alert(err.response?.data?.message || "Failed to remove user"));
  };

  return (
    <div>
      <h2>Manage Users</h2>

      <h3>Add User</h3>
      <input placeholder="Name" value={name} onChange={e => setName(e.target.value)} />
      <select value={role} onChange={e => setRole(e.target.value)}>
        <option>STUDENT</option>
        <option>ADMIN</option>
        <option>FACULTY</option>
        <option>EVENT_ORGANISER</option>
        <option>GUEST</option>
      </select>
      <input placeholder="Username" value={username} onChange={e => setUsername(e.target.value)} />
      <input placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} />
      <button onClick={addUser}>Add User</button>

      <h3>All Users</h3>
      <table>
        <thead>
          <tr><th>Name</th><th>Role</th><th>Username</th><th>Action</th></tr>
        </thead>
        <tbody>
          {users.map(u => (
            <tr key={u.id}>
              <td>{u.name}</td>
              <td>{u.role}</td>
              <td>{u.username}</td>
              <td><button onClick={() => removeUser(u.id)}>Remove</button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
