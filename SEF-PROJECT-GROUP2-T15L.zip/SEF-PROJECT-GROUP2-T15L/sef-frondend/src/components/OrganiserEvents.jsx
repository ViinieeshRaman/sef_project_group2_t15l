import { useEffect, useState } from "react";

export default function OrganiserEvents() {
  const [events, setEvents] = useState([]);

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("user"));
    if (!user) return;

    fetch(`http://localhost:5000/api/event-organiser/my-events?user_id=${user.id}`)
      .then(res => res.json())
      .then(data => setEvents(data))
      .catch(err => console.error("Failed to load events", err));
  }, []);

  return (
    <div className="card">
      <h2>My Events & Venue Booking Status</h2>

      {events.length === 0 ? (
        <p>No events created yet</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Event Title</th>
              <th>Date</th>
              <th>Booking Status</th>
            </tr>
          </thead>
          <tbody>
            {events.map(e => (
              <tr key={e.id}>
                <td>{e.title}</td>
                <td>{e.event_date}</td>
                <td>{e.booking_status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
