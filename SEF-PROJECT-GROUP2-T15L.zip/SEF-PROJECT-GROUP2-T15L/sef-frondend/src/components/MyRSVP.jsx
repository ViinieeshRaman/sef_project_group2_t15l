import { useEffect, useState } from "react";
import axios from "axios";

export default function MyRSVPs({ userId }) {
  const [rsvps, setRsvps] = useState([]);

  const fetchRSVPs = () => {
    axios
      .get(`http://localhost:5000/api/guest/rsvps/${userId}`)
      .then((res) => setRsvps(res.data))
      .catch((err) => console.error(err));
  };

  useEffect(() => {
    fetchRSVPs();
  }, [userId]);

  return (
    <div>
      <h2>My RSVPs</h2>
      {rsvps.length === 0 ? (
        <p>No RSVPs yet</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Event</th>
              <th>Venue</th>
              <th>Date</th>
              <th>Time</th>
            </tr>
          </thead>
          <tbody>
            {rsvps.map((r, i) => (
              <tr key={i}>
                <td>{r.event_name}</td>
                <td>{r.venue_name}</td>
                <td>{r.event_date}</td>
                <td>{r.start_time} - {r.end_time}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
