import { useEffect, useState } from "react";
import axios from "axios";

export default function EventCalendar() {
  const [events, setEvents] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/faculty/events")
      .then((res) => setEvents(res.data))
      .catch((err) => console.error(err));
  }, []);

  // group events by date
  const eventsByDate = events.reduce((acc, e) => {
    const date = e.event_date;
    if (!acc[date]) acc[date] = [];
    acc[date].push(e);
    return acc;
  }, {});

  return (
    <div>
      <h2>All Events (Calendar View)</h2>
      {Object.keys(eventsByDate).length === 0 ? (
        <p>No events found</p>
      ) : (
        Object.keys(eventsByDate).map((date) => (
          <div key={date} style={{ marginBottom: "20px" }}>
            <h3>{new Date(date).toLocaleDateString("en-CA")}</h3>
            <ul>
              {eventsByDate[date].map((e) => (
                <li key={e.id}>
                  {e.event_name} - {e.organiser_name} ({e.description})
                </li>
              ))}
            </ul>
          </div>
        ))
      )}
    </div>
  );
}
