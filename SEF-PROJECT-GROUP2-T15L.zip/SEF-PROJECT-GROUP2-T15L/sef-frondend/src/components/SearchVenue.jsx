import axios from "axios";
import { useState } from "react";

export default function SearchVenue() {
  const [date, setDate] = useState("");
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [venues, setVenues] = useState([]);
  const [purpose, setPurpose] = useState(""); // new
  const [loading, setLoading] = useState(false);

  const user = JSON.parse(localStorage.getItem("user"));

  function searchVenues() {
    if (!date || !startTime || !endTime) {
      alert("Please select date and time");
      return;
    }

    setLoading(true);

    axios
      .get("http://localhost:5000/api/student/venues/search", {
        params: { date, startTime, endTime },
      })
      .then((res) => setVenues(res.data))
      .catch((err) => {
        console.error(err);
        alert("Error searching venues");
      })
      .finally(() => setLoading(false));
  }

  function bookVenue(venueId) {
    if (!user) {
      alert("User not logged in");
      return;
    }

    if (!purpose.trim()) {
      alert("Please enter purpose of booking");
      return;
    }

    axios
      .post("http://localhost:5000/api/student/bookings", {
        venueId,
        bookingDate: date,
        startTime,
        endTime,
        purpose, // include purpose
        userId: user.id,
      })
      .then(() => {
        alert("Booking submitted for approval");
        setVenues(venues.filter((v) => v.id !== venueId));
        setPurpose(""); // reset purpose
      })
      .catch((err) => {
        console.error(err);
        alert(err.response?.data?.message || "Booking failed");
      });
  }

  return (
    <div>
      <h2>Search Available Venues</h2>

      <div>
        <label>Date</label>
        <br />
        <input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
      </div>

      <div>
        <label>Start Time</label>
        <br />
        <input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} />
      </div>

      <div>
        <label>End Time</label>
        <br />
        <input type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} />
      </div>

      <div>
        <label>Purpose</label>
        <br />
        <input
          type="text"
          placeholder="Purpose of Booking"
          value={purpose}
          onChange={(e) => setPurpose(e.target.value)}
        />
      </div>

      <br />

      <button onClick={searchVenues}>{loading ? "Searching..." : "Search"}</button>

      <br />
      <br />

      {venues.length === 0 ? (
        <p>No venues available</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Venue Name</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {venues.map((v) => (
              <tr key={v.id}>
                <td>{v.venue_name}</td>
                <td>
                  <button onClick={() => bookVenue(v.id)}>Book</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
