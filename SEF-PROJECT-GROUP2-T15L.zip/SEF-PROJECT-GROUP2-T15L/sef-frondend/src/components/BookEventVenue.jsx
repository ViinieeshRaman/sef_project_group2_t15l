import { useEffect, useState } from "react";

export default function BookEventVenue() {
  const [events, setEvents] = useState([]);
  const [venues, setVenues] = useState([]);

  const [eventId, setEventId] = useState("");
  const [venueId, setVenueId] = useState("");
  const [date, setDate] = useState("");
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");

  const [resources, setResources] = useState([]);

  
  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("user"));
    if (!user) return;

    
    fetch(`http://localhost:5000/api/event-organiser/events?user_id=${user.id}`)
      .then(res => res.json())
      .then(data => setEvents(data))
      .catch(err => console.error("Failed to load events", err));

    
    fetch("http://localhost:5000/api/faculty/venues")
      .then(res => res.json())
      .then(data => setVenues(data))
      .catch(err => console.error("Failed to load venues", err));
  }, []);

  
  const toggleResource = (resource) => {
    setResources(prev =>
      prev.includes(resource)
        ? prev.filter(r => r !== resource)
        : [...prev, resource]
    );
  };

  
  const handleSubmit = async (e) => {
    e.preventDefault();
    const user = JSON.parse(localStorage.getItem("user"));
    if (!user) return alert("User not logged in");

    if (!eventId) return alert("Please select an event");
    if (!venueId) return alert("Please select a venue");

    try {
      const response = await fetch(
        "http://localhost:5000/api/event-organiser/bookings",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            event_id: eventId,
            venue_id: venueId,
            booking_date: date,
            start_time: startTime,
            end_time: endTime,
            resources,
            user_id: user.id
          })
        }
      );

      const data = await response.json();

      if (response.ok) {
        alert("Venue booking submitted for approval");
        setEventId("");
        setVenueId("");
        setDate("");
        setStartTime("");
        setEndTime("");
        setResources([]);
      } else {
        alert("Booking failed: " + data.message);
      }
    } catch (err) {
      console.error(err);
      alert("Booking failed: " + err.message);
    }
  };

  
  return (
    <div className="card">
      <h2>Book Venue for Event</h2>

      <form onSubmit={handleSubmit}>
        {/* Event */}
        <select
          value={eventId}
          onChange={(e) => setEventId(e.target.value)}
          required
        >
          <option value="">Select Event</option>
          {events.map(event => (
            <option key={event.id} value={event.id}>
              {event.title} ({event.event_date})
            </option>
          ))}
        </select>

        {/* Venue */}
        <select
          value={venueId}
          onChange={(e) => setVenueId(e.target.value)}
          required
        >
          <option value="">Select Venue</option>
          {venues.map(v => (
            <option key={v.id} value={v.id}>
              {v.venue_name} ({v.location})
            </option>
          ))}
        </select>

        {/* Date & Time */}
        <input
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          required
        />

        <input
          type="time"
          value={startTime}
          onChange={(e) => setStartTime(e.target.value)}
          required
        />

        <input
          type="time"
          value={endTime}
          onChange={(e) => setEndTime(e.target.value)}
          required
        />

        {/* Resources */}
        <div className="resource-section">
          <label>Resources Needed</label>
          <div className="resource-grid">
            {["Microphone", "Projector", "Speaker", "Whiteboard"].map(item => (
              <div
                key={item}
                className={`resource-chip ${resources.includes(item) ? "active" : ""}`}
                onClick={() => toggleResource(item)}
              >
                {item}
              </div>
            ))}
          </div>
        </div>

        <button type="submit">Submit Booking</button>
      </form>
    </div>
  );
}
