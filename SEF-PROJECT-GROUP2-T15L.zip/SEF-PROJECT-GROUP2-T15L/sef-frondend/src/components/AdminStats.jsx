import { useEffect, useState } from "react";
import axios from "axios";

export default function AdminStats() {
  const [stats, setStats] = useState(null);

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/admin/stats")
      .then((res) => setStats(res.data))
      .catch((err) => console.error("Failed to fetch stats", err));
  }, []);

  if (!stats) return <p>Loading statistics...</p>;

  return (
    <div className="card">
      <h2>Analytics Overview</h2>
      <div className="stats-grid">
        <div className="stat-card">
          <h3>Total Bookings</h3>
          <p>{stats.totalBookings}</p>
        </div>
        <div className="stat-card">
          <h3>Approved Bookings</h3>
          <p>{stats.approvedBookings}</p>
        </div>
        <div className="stat-card">
          <h3>Rejected Bookings</h3>
          <p>{stats.rejectedBookings}</p>
        </div>
        <div className="stat-card">
          <h3>Pending Bookings</h3>
          <p>{stats.pendingBookings}</p>
        </div>
        <div className="stat-card">
          <h3>Total Events</h3>
          <p>{stats.totalEvents}</p>
        </div>
        <div className="stat-card">
          <h3>Total Users</h3>
          <p>{stats.totalUsers}</p>
        </div>
      </div>
    </div>
  );
}
