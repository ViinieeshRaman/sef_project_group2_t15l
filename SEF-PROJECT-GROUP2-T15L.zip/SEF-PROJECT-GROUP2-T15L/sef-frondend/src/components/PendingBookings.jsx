import axios from "axios";
import { useEffect, useState } from "react";

export default function PendingBookings() {
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    fetchPendingBookings();
  }, []);

  function fetchPendingBookings() {
    axios
      .get("http://localhost:5000/api/admin/bookings/pending")
      .then((res) => setBookings(res.data));
  }

  function approveBooking(id) {
    axios
      .put(`http://localhost:5000/api/admin/bookings/${id}/approve`)
      .then(() => fetchPendingBookings());
  }

  function rejectBooking(id) {
    axios
      .put(`http://localhost:5000/api/admin/bookings/${id}/reject`)
      .then(() => fetchPendingBookings());
  }

  function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-CA");
  }

  return (
    <div>
      <h2>Pending Bookings</h2>

      <table>
        <thead>
          <tr>
            <th>Student</th>
            <th>Venue</th>
            <th>Date</th>
            <th>Time</th>
            <th>Purpose</th>
            <th>Action</th>
          </tr>
        </thead>

        <tbody>
          {bookings.length === 0 ? (
            <tr>
              <td colSpan="6" align="center">
                No pending bookings
              </td>
            </tr>
          ) : (
            bookings.map((b) => (
              <tr key={b.id}>
                <td>{b.student_name}</td>
                <td>{b.venue_name}</td>
                <td>{formatDate(b.booking_date)}</td>
                <td>
                  {b.start_time} – {b.end_time}
                </td>
                <td>{b.purpose}</td>
                <td>
                  <button onClick={() => approveBooking(b.id)}>Approve</button>
                  <button onClick={() => rejectBooking(b.id)}>Reject</button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}
