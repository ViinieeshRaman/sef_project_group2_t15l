import { useEffect, useState } from "react";

export default function OrganiserFeedback() {
  const [feedbacks, setFeedbacks] = useState([]);

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("user"));
    if (!user) return;

    fetch(`http://localhost:5000/api/event-organiser/feedbacks?user_id=${user.id}`)
      .then(res => res.json())
      .then(data => setFeedbacks(data))
      .catch(err => console.error("Failed to load feedbacks", err));
  }, []);

  return (
    <div className="card">
      <h2>Feedback for My Events</h2>

      {feedbacks.length === 0 ? (
        <p>No feedback received yet</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Event</th>
              <th>Rating</th>
              <th>Comment</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            {feedbacks.map(f => (
              <tr key={f.id}>
                <td>{f.event_title}</td>
                <td>{f.rating}</td>
                <td>{f.comment}</td>
                <td>{new Date(f.created_at).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
