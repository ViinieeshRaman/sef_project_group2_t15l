import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/login.css";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();

    try {
      const res = await fetch("http://localhost:5000/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });

      if (!res.ok) {
        alert("Invalid login");
        return;
      }

      const user = await res.json();

      // store user session
      localStorage.setItem("user", JSON.stringify(user));

      // role-based redirect
      if (user.role === "STUDENT") navigate("/student");
      else if (user.role === "ADMIN") navigate("/admin");
      else if (user.role === "FACULTY") navigate("/faculty");
      else if (user.role === "EVENT_ORGANISER") navigate("/organiser");
      else if (user.role === "GUEST") navigate("/guest");
      else alert("Unknown role");
    } catch (err) {
      console.error(err);
      alert("Login failed. Try again.");
    }
  }

  return (
    <div className="login-page">
      <div className="login-card">
        <h1>Campus Venue Management System</h1>
        <p className="subtitle">Please sign in to your account</p>

        <form onSubmit={handleSubmit}>
          <label>Username</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />

          <label>Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />

          <button type="submit">Sign In</button>
        </form>

        {/* Signup link */}
        <p style={{ marginTop: "10px", textAlign: "center" }}>
          Don’t have an account?{" "}
          <span
            style={{ color: "#3b82f6", cursor: "pointer" }}
            onClick={() => navigate("/signup")}
          >
            Sign up here
          </span>
        </p>
      </div>
    </div>
  );
}
