import { useState } from "react";
import PendingBookings from "../components/PendingBookings";
import AllBookings from "../components/AllBookings";
import ManageUsers from "../components/ManageUsers";
import ViewVenues from "../components/ViewVenues";
import AdminStats from "../components/AdminStats"; // NEW: Analytics component
import "../styles/admin.css";

export default function AdminDashboard() {
  const [view, setView] = useState("pending");

  return (
    <div className="container">
      <h1>Admin Dashboard</h1>

      {/* ACTION BUTTONS */}
      <div className="admin-actions">
        <button onClick={() => setView("pending")}>Pending Bookings</button>
        <button onClick={() => setView("allBookings")}>All Bookings</button>
        <button onClick={() => setView("users")}>Manage Users</button>
        <button onClick={() => setView("venues")}>View Venues</button>
        <button onClick={() => setView("stats")}>Analytics</button> {/* NEW */}
      </div>

      {/* MAIN CONTENT */}
      <div className="content">
        {view === "pending" && <PendingBookings />}
        {view === "allBookings" && <AllBookings />}
        {view === "users" && <ManageUsers />}
        {view === "venues" && <ViewVenues />}
        {view === "stats" && <AdminStats />} {/* NEW */}
      </div>
    </div>
  );
}
