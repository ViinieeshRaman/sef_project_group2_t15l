import { useState } from "react";
import CreateEvent from "../components/CreateEvent";
import BookEventVenue from "../components/BookEventVenue";
import OrganiserEvents from "../components/OrganiserEvents";
import OrganiserFeedback from "../components/OrganiserFeedback";
import "../styles/eventOrganiser.css";

export default function EventOrganiserDashboard() {
  const [view, setView] = useState("");

  return (
    <div className="page organiser-page">
      <header className="header organiser-header">
        <h1>Campus Venue Management System</h1>
        <p>Event Organiser Dashboard</p>
      </header>

      <div className="dashboard-actions organiser-actions">
        <div
          className={`action-card ${view === "create" ? "active" : ""}`}
          onClick={() => setView("create")}
        >
          <span className="icon">🎉</span>
          <h3>Create Event</h3>
          <p>Create event details</p>
        </div>

        <div
          className={`action-card ${view === "book" ? "active" : ""}`}
          onClick={() => setView("book")}
        >
          <span className="icon">🏢</span>
          <h3>Book Venue</h3>
          <p>Book venue for event & request resources</p>
        </div>

        <div
          className={`action-card ${view === "my-events" ? "active" : ""}`}
          onClick={() => setView("my-events")}
        >
          <span className="icon">📅</span>
          <h3>My Events</h3>
          <p>View events & booking status</p>
        </div>

        {/* NEW FEEDBACK CARD */}
        <div
          className={`action-card ${view === "feedback" ? "active" : ""}`}
          onClick={() => setView("feedback")}
        >
          <span className="icon">💬</span>
          <h3>Event Feedback</h3>
          <p>View feedback from participants</p>
        </div>
      </div>

      <div className="content organiser-content">
        {view === "create" && <CreateEvent />}
        {view === "book" && <BookEventVenue />}
        {view === "my-events" && <OrganiserEvents />}
        {view === "feedback" && <OrganiserFeedback />}
      </div>
    </div>
  );
}
