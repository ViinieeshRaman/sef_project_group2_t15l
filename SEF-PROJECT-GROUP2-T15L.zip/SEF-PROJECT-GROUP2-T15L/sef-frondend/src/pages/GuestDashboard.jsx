import { useState } from "react";
import ViewEvents from "../components/ViewEvents";
import MyEvents from "../components/MyEvents";

export default function GuestDashboard() {
  const [view, setView] = useState("view"); 
  const user = JSON.parse(localStorage.getItem("user")); 

  return (
    <div className="page">
      <header className="header">
        <h1>Campus Venue Management System</h1>
        <p>Guest Dashboard</p>
      </header>

      <div className="dashboard-actions">
        <div className="action-card" onClick={() => setView("view")}>
          🎫
          <h3>View Events</h3>
          <p>See all available events</p>
        </div>

        <div className="action-card" onClick={() => setView("my")}>
          📅
          <h3>My Events</h3>
          <p>See events you RSVPed</p>
        </div>
      </div>

      <div className="content">
        {view === "view" && <ViewEvents user={user} />}
        {view === "my" && <MyEvents user={user} />}
      </div>
    </div>
  );
}
