import { useState } from "react";
import VenueBlocker from "../components/VenueBlocker";
import EventList from "../components/EventList";
import EventCalendar from "../components/EventCalendar";
import "../styles/faculty.css";

export default function FacultyDashboard() {
  const [view, setView] = useState("blocker"); 

  return (
    <div className="faculty-page">
      <h1>Faculty Manager Dashboard</h1>

      <div className="dashboard-actions">
        <div className="action-card" onClick={() => setView("blocker")}>
          🛑
          <h3>Block Venue</h3>
          <p>Block a venue for maintenance or events</p>
        </div>

        <div className="action-card" onClick={() => setView("list")}>
          📄
          <h3>View Events (List)</h3>
          <p>See all scheduled events</p>
        </div>

        <div className="action-card" onClick={() => setView("calendar")}>
          📅
          <h3>View Events (Calendar)</h3>
          <p>See events in calendar view</p>
        </div>
      </div>

      <div className="content">
        {view === "blocker" && <VenueBlocker />}
        {view === "list" && <EventList />}
        {view === "calendar" && <EventCalendar />}
      </div>
    </div>
  );
}
