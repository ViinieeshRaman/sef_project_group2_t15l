import { useState } from "react";
import SearchVenue from "../components/SearchVenue";
import MyBookings from "../components/MyBookings";
import "../styles/student.css";

export default function StudentDashboard() {
  const [view, setView] = useState("search");

  return (
    <div className="page">
      <header className="header">
        <h1>Campus Venue Management System</h1>
        <p>Student Dashboard</p>
      </header>

      <div className="dashboard-actions">
        <div className="action-card" onClick={() => setView("search")}>
          🔍
          <h3>Search Venue</h3>
          <p>Find available venues and make booking</p>
        </div>

        <div className="action-card" onClick={() => setView("bookings")}>
          📄
          <h3>My Bookings</h3>
          <p>View, modify, or cancel bookings</p>
        </div>
      </div>

      <div className="content">
        {view === "search" && <SearchVenue />}
        {view === "bookings" && <MyBookings />}
      </div>
    </div>
  );
}
