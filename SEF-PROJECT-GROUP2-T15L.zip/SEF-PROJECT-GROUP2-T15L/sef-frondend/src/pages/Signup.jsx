import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/login.css"; 

export default function Signup() {
  const [name, setName] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("STUDENT"); 
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();

    try {
      const res = await fetch("http://localhost:5000/api/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, username, password, role }),
      });

      if (!res.ok) {
        const err = await res.json();
        alert(err.message || "Signup failed");
        return;
      }

      alert("Account created successfully! Please login.");
      navigate("/login");
    } catch (err) {
      console.error(err);
      alert("Signup failed. Try again.");
    }
  }

  return (
    <div className="login-page">
      <div className="login-card">
        <h1>Campus Venue Management System</h1>
        <p className="subtitle">Create a new account</p>

        <form onSubmit={handleSubmit}>
          <label>Full Name</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />

          <label>Username</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />

          <label>Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />

          <label>Role</label>
          <select value={role} onChange={(e) => setRole(e.target.value)}>
            <option value="STUDENT">Student</option>
            <option value="EVENT_ORGANISER">Event Organiser</option>
            <option value="GUEST">Guest</option>
          </select>

          <button type="submit">Sign Up</button>
        </form>

        {/* Login link */}
        <p style={{ marginTop: "10px", textAlign: "center" }}>
          Already have an account?{" "}
          <span
            style={{ color: "#3b82f6", cursor: "pointer" }}
            onClick={() => navigate("/login")}
          >
            Login here
          </span>
        </p>
      </div>
    </div>
  );
}
