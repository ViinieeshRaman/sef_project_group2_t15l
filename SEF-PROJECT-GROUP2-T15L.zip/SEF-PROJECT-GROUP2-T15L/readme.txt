Project Setup Guide
This project is a web application built using React.js (frontend), Node.js/Express (backend), and PostgreSQL (database). Follow the steps below to set up the environment and run the system locally.

Prerequisites:-
Make sure the following software is installed:
Node.js (v16 or above)
npm (comes with Node.js)
PostgreSQL
Git

For Frontend:
cd into the sef-fronend folder.
run:
npm install
npm run dev

For Backend:
cd into sef-backend.
run: 
npm install
node server.js

For Database:
Make sure Postgress and pgadmin4 is downloaded and setup.
import backup database file into the pgadmin4.
under sef-backend/db.js:
edit and update your pgadmin port number and password.


Sample Credentials For Each user:
Student:
username: student1
password: 1234

Admin:
username: admin1
password: 1234

Faculty Manager:
username: faculty1
password: 1234

Event Organiser:
username: organiser1
password: 1234

Guest:
username: guest1
password: 1234